#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <unistd.h>
#define exit_on_error(s,m) if (s<0) {perror(m); exit(1);}
#define exit_on_null(s,m) if (s==NULL) {perror(m); exit(1);}
#define MAX_OUV 20
#define MAX_PL 20
#define MAX_MUS 20
int idsemO;

struct sembuf DOWN_read = {0, -1, 0}; 
struct sembuf UP_read = {0, 1, 0}; 
struct sembuf DOWN_write = {0, -100, 0};
struct sembuf UP_write = {0, 100, 0};

void semaforoOp(int id, struct sembuf *sops , const char *erro ){
//    printf("Valor do semaforo antes %s: %d\n",  erro, semctl(id,0,GETVAL) );
    int status;
    status = semop(id,sops,1);
//    printf("Valor do semaforo depois %s: %d\n",  erro, semctl(id,0,GETVAL) );
    exit_on_error(status,erro);
    }

void conectarSemaforo(int chave,int *id){
*id = semget ( chave, 1, 0666 ); // criacao de sinal
  
  if(*id<0){ //Nao esta criado, vai ser criado
    *id = semget ( chave, 1,  IPC_CREAT | 0666 );
    exit_on_error (id, "Cria��o/Liga��o"); //o do meio e o numero de sinais
    
    int status = semctl (*id, 0, SETVAL, 100);  //Sinal operation 
    exit_on_error (status, "Inicializa��o"); //inicializa
  }
}

typedef struct {
	char ID_MUS[10];
	char artista[50];
	char nome[60];
  int duracao;
  int ano_producao;
  char genero[60];
	int n_vezes;
} Tmusica;

typedef struct {
	char ID_PL[10];
	char nome[60];
	char musicas[250];
} Tplaylist;

typedef struct {
	char nick[50];
	char pass[50];
	int num;
	char playlists[250];
} Touvinte;


typedef struct {
	long tipo;
	struct {
		char operacao[50];
		char info1[250];
		char info3[250];
		int myid;
	} dados;
} MsgOuvinte2Server;

typedef struct {
	long tipo;
	struct {
		Tmusica musica;
		char info1[250];
		int valor1;
		int status;
    int myid;
	} dados;
} MsgServer2Ouvinte;

void estado_semaforo(int id_sem, unsigned short num_sem){
int status = semctl(id_sem, num_sem, GETVAL, 0);
printf("estado do semaforo: %d\n", status);
}

int valor_semaforo(int id_sem, unsigned short num_sem){
int status = semctl(id_sem, num_sem, GETVAL, 0);
return status;
}
