#include "includes.h"
#define MAX_OUV 20
#define MAX_PL 20
#define MAX_MUS 20

Touvinte* ouv;
int idsemS;

//so atualiza os ouvintes.txt de momento falta a playlists e musicas
void descarrega_memoria_ouvintes(Touvinte* ouv){ //Recebe um ouvinte da shm e atualiza os ficheiros
	FILE *f = fopen("ouvintes.txt", "w");
	if (f==NULL) { perror("Erro de escrita: "); exit(3); } ;
	int i;
	for (i=0; (i < MAX_OUV) && ( ouv[i].num != 0 ) ; i++ ) {
		fprintf(f, "%s:%s:%d:nome:email:curso:%s\n",ouv[i].nick, ouv[i].pass, ouv[i].num, ouv[i].playlists );
	}
	fclose(f);
 printf("\n+++ Descarga de ouvintes feita com sucesso +++\n");
}

void descarrega_memoria_musicas(Tmusica* mus){ 
	FILE *f = fopen("Musicas.txt", "w");
	if (f==NULL) { perror("Erro de escrita: "); exit(3); } ;
	int i;
	for (i=0; (i < MAX_MUS) ; i++ ) {
   int c = strcmp(mus[i].ID_MUS,"");
		if( c!=0){
		fprintf(f, "%s:%s:%s:%d:%d:%s:%d\n",mus[i].ID_MUS, mus[i].nome, mus[i].artista, mus[i].duracao, mus[i].ano_producao,mus[i].genero, mus[i].n_vezes );
   }
 }
	fclose(f);
 printf("+++ Descarga de musicas feita com sucesso +++\n");
}

void descarrega_memoria_playlists(Tplaylist* play){ //falta
  FILE *f = fopen("Playlists.txt", "w");
	if (f==NULL) { perror("Erro de escrita: "); exit(3); } ;
	int i;
	for (i=0; (i < MAX_PL) ; i++ ) {
   int c = strcmp(play[i].ID_PL,"vazio");
		if( c!=0){
		  fprintf(f, "%s:%s:%s\n",play[i].ID_PL, play[i].nome, play[i].musicas );
     }
	}
	fclose(f);
 printf("+++ Descarga de playlists feita com sucesso +++\n");
}

void descarrega_memoria(Touvinte* ouv, Tmusica* mus, Tplaylist* play){
descarrega_memoria_ouvintes(ouv);
descarrega_memoria_musicas(mus); 
descarrega_memoria_playlists(play); 
}


void mostra_memoria_ouvinte(Touvinte *ouv){ // da print da memoria
	for (int u = 0; u < MAX_OUV; u++ ) {
		if(ouv[u].num>0){//resolvver
			printf ("Ouvinte %d: %s %s %d %s\n",u+1, ouv[u].nick, ouv[u].pass, ouv[u].num, ouv[u].playlists );
		}
	}
}

void mostra_memoria_musicas(Tmusica *mus){
	for (int u = 0; u < MAX_MUS; u++ ) {
  int i = strcmp(mus[u].ID_MUS,"");
		if( i!=0){
			printf ("Musica %d: %s %s %s %d %d %s %d \n",u+1, mus[u].ID_MUS, mus[u].nome, mus[u].artista, mus[u].duracao, mus[u].ano_producao, mus[u].genero, mus[u].n_vezes);
		}
	}
}

void mostra_memoria_playlists(Tplaylist *play){
	for (int u = 0; u < MAX_PL; u++ ) {
  int i = strcmp(play[u].ID_PL,"vazio");
		if( i!=0){
			printf ("Playlist %d: %s %s %s \n",u+1, play[u].ID_PL, play[u].nome, play[u].musicas);
		}
	}
}

void mostra_memoria(Touvinte *ouv, Tmusica *mus, Tplaylist *play){
printf("\n");
mostra_memoria_ouvinte(ouv);
printf("\n");
mostra_memoria_musicas(mus);
printf("\n");
mostra_memoria_playlists(play);
}


void obter_substring(char linha[], char resultado[], char separador, int indice) { //funcao elementar
	int i, j=0, meu_indice = 0;
	for (i=0; linha[i] != '\0'; i++) {
		if ( linha[i] == separador ) {
			meu_indice++;
		} else if (meu_indice == indice) {
			resultado[j++]=linha[i];
		}
	}
	resultado[j]='\0';
}

void inicializa_mem_ouvintes(Touvinte *ouv){ //comeca a criar a memeoria dos ouvintes

	for(int i=0;i<MAX_OUV;i++){
		strcpy(ouv[i].nick, "vazio"); 
		strcpy(ouv[i].pass, "vazio");
		ouv[i].num=0;
		strcpy(ouv[i].playlists, "vazio");
	}
}

void inicializa_mem_musicas(Tmusica *mus){ //comeca a criar a memeoria das musicas
 
  for(int i=0;i<MAX_MUS;i++){
		strcpy(mus[i].ID_MUS, "vazio"); 
		strcpy(mus[i].nome, "vazio");
		strcpy(mus[i].artista, "vazio");
    mus[i].duracao=0;
    mus[i].ano_producao=0;
    strcpy(mus[i].genero, "vazio");
    mus[i].n_vezes=0;
	}
}
void inicializa_mem_playlists(Tplaylist *play){ //comeca a criar a memeoria das playlist

  for(int i=0;i<MAX_PL;i++){
		strcpy(play[i].ID_PL, "vazio"); 
		strcpy(play[i].nome, "vazio");
		strcpy(play[i].musicas, "vazio");
	}
}

void carrega_mem_ouvintes(Touvinte *ouv){ //Funcional!!
	int n=0;
	char linha[250];
	char tmp[100];
	FILE *fouvinte = fopen ("ouvintes.txt", "r");
	int i = 0;
	int pos=0;
 semaforoOp(idsemS, &DOWN_write,"DOWN a atualizar..." );
	while ( fgets(linha, 250, fouvinte ) != NULL ){
		linha[strlen(linha)-1]='\0';
		if ( pos < MAX_OUV ){
			strcpy(ouv[pos].playlists, "");
			obter_substring(linha,ouv[pos].nick,':',0);
			obter_substring(linha,ouv[pos].pass,':',1);
			obter_substring(linha,tmp,':',2);
			ouv[pos].num=atoi(tmp);

			for(int j=0;j<strlen(linha);j++){
				if(linha[j] == ':'){
					n++;
				}
			}
			for(int k=6; k<n+1; k++){
				obter_substring(linha,tmp, ':',k);
				strcat(tmp,":");
				strcat(ouv[pos].playlists, tmp);
				strcat(tmp,"");
			}
			ouv[pos].playlists[strlen(ouv[pos].playlists)-1]='\0';
			n=0;
			pos++;
		}else {
			printf("Impossivel carregar toda a memoria. Espaco insuficiente\n");
		}
		i++;
	}
	fclose(fouvinte);
 printf("\n>>> Memoria carregada com os ouvintes feito com sucesso! <<<\n");
semaforoOp(idsemS, &UP_write,"DOWN a atualizar..." );
}

void carrega_mem_musica(Tmusica *mus){
	char linha[250];
	char tmp1[10],tmp2[10],tmp3[10];
	FILE *fmusicas = fopen ("musicas.txt", "r");
	int i = 0;
	int pos=0;
 semaforoOp(idsemS, &DOWN_write,"DOWN a atualizar..." );
	while ( fgets(linha, 250, fmusicas ) != NULL ){
		linha[strlen(linha)-1]='\0';
		if ( pos < MAX_MUS ){ 
			obter_substring(linha,mus[pos].ID_MUS,':',0); 
			obter_substring(linha,mus[pos].nome,':',1);
      obter_substring(linha,mus[pos].artista,':',2);
      obter_substring(linha,tmp1,':',3); 
			obter_substring(linha,tmp2,':',4);
      mus[pos].duracao=atoi(tmp1);
      mus[pos].ano_producao=atoi(tmp2);
      obter_substring(linha,mus[pos].genero,':',5);
      obter_substring(linha,tmp3,':',6); 
      mus[pos].n_vezes=atoi(tmp3);
			pos++;
		}else {
			printf("Impossivel carregar toda a memoria. Espaco insuficiente\n");
		}
		i++;
	}
	fclose(fmusicas);
 printf(">>> Memoria carregada com as musicas feita com sucesso! <<<\n");
 semaforoOp(idsemS, &UP_write,"DOWN a atualizar..." );
}

void carrega_mem_playlits(Tplaylist *play){
	int n=0;
	char linha[250];
	char tmp[100];
	FILE *fplaylists = fopen ("playlists.txt", "r");
	int i = 0;
	int pos=0;
 semaforoOp(idsemS, &DOWN_write,"DOWN a atualizar..." );
	while ( fgets(linha, 250, fplaylists ) != NULL ){
		linha[strlen(linha)-1]='\0';
		if ( pos < MAX_PL ){
			strcpy(play[pos].musicas, ""); // erro aqui, acho que nao esta a abri o play 
			obter_substring(linha,play[pos].ID_PL,':',0);  //erro aqui!!!
			obter_substring(linha,play[pos].nome,':',1);

			for(int j=0;j<strlen(linha);j++){
				if(linha[j] == ':'){
					n++;
				}
			}
			for(int k=2; k<n+1; k++){
				obter_substring(linha,tmp, ':',k);
				strcat(tmp,":");
				strcat(play[pos].musicas, tmp);
				strcat(tmp,"");
			}
			play[pos].musicas[strlen(play[pos].musicas)-1]='\0';
			n=0;
			pos++;
		}else {
			printf("Impossivel carregar toda a memoria. Espaco insuficiente\n");
		}
		i++;
	}
	fclose(fplaylists);
 printf(">>> Memoria carregada com as playlists feita com sucesso! <<<\n");
 semaforoOp(idsemS, &UP_write,"DOWN a atualizar..." );

}


void carrega_memoria(Touvinte* ouv, Tmusica* mus, Tplaylist* play){
carrega_mem_ouvintes(ouv); 
carrega_mem_musica(mus); 
carrega_mem_playlits(play); 
}

int main() { 
int a=0;
	Touvinte *ouv;	//cria um apontador ouvinte
 int mem_ouv=shmget(11011, MAX_OUV * sizeof(Touvinte) , 0);
  if (mem_ouv<0){ //Nao esta criado, vai ser criado!
		int mem_ouv=shmget(11011, MAX_OUV * sizeof(Touvinte) , IPC_CREAT |IPC_EXCL| 0666 );
		exit_on_error(mem_ouv, "shmget ouvintes1");
		ouv = (Touvinte *)shmat(mem_ouv, 0 , 0);
		exit_on_null(ouv, "erro no attach");
   inicializa_mem_ouvintes(ouv);
   printf("\n>>> memoria de ouvintes criada <<<\n");
	}else {
		ouv = (Touvinte *)shmat(mem_ouv, 0 , 0);
		exit_on_null(ouv, "erro no attach");
	
   printf("\n>>> memoria de ouvintes atualizada <<<\n");	
	} //cira memoria ouvinte
  
  Tmusica *mus; // cria apontador musica
   int mem_mus=shmget(22022, MAX_MUS * sizeof(Tmusica) , 0);
  if (mem_mus<0){ //Nao esta criado, vai ser criado!
    int mem_mus=shmget(22022, MAX_MUS * sizeof(Tmusica) , IPC_CREAT |IPC_EXCL| 0666 );
		exit_on_error(mem_mus, "shmget musica1");
		mus = (Tmusica *)shmat(mem_mus, 0 , 0);
		exit_on_null(mus, "erro no attach");
   //inicializa_mem_musicas(mus);
   printf(">>> memoria de musicas criada <<<\n");
	}else {
		mus = (Tmusica *)shmat(mem_mus, 0 , 0);
		exit_on_null(mus, "erro no attach");
   
    printf(">>> memoria de musicas atualizada <<<\n");
	} // cira memoria musica
 
 Tplaylist *play;   // cira apontador playlists
 int mem_play=shmget(33033, MAX_PL * sizeof(Tplaylist) , 0);
  if (mem_play<0){
    int mem_play=shmget(33033, MAX_PL * sizeof(Tplaylist) , IPC_CREAT |IPC_EXCL| 0666 );
		exit_on_error(mem_play, "shmget playlist");
		play = (Tplaylist *)shmat(mem_play, 0 , 0);
		exit_on_null(play, "erro no attach");
   inicializa_mem_playlists(play);
   printf(">>> memoria de playlists criada <<<\n");
	}else {
		play = (Tplaylist *)shmat(mem_play, 0 , 0);
		exit_on_null(play, "erro no attach");
   
		printf(">>> memoria de playlists atualizada <<<\n");
	} // cira memoria playlists
  
  
  
	conectarSemaforo(80808,&idsemS);
  printf("\n>>> Semaforos foram criados <<<\n");
 
 
 
  int MsgOuvinte2Server;
  MsgOuvinte2Server = msgget ( 55055, 0600 | IPC_CREAT );
  exit_on_error (MsgOuvinte2Server, "Criacao/Ligacao");
  printf("\n>>> Fila de mensagens Ouvinte2Server criada <<<\n");
  
  int MsgServer2Ouvinte;
  MsgServer2Ouvinte = msgget ( 66066, 0600 | IPC_CREAT );
  exit_on_error (MsgServer2Ouvinte, "Criacao/Ligacao");
 
  printf(">>> Fila de mensagens Server2Ouvinte criada <<<\n");
 
while(1){
  printf("\n-------- MENU --------\n 1. Carregar ficheiros\n 2. Descarregar memoria\n 3. Manutencao aplicacao\n 4. Mostrar Memoria\n 0. Sair\n");
  int number;
  scanf( "%d", &number);
  switch(number){

  case 1 :
  printf("A Carregar ficheiros...\n");
  sleep(1);
  carrega_memoria(ouv,mus,play);
  break;

  case 2 :
  printf("A Descarregar memoria...\n");
  sleep(1);
  descarrega_memoria(ouv,mus,play);
  break;
  
  case 3 :
  semaforoOp(idsemS, &DOWN_write,"DOWN a atualizar..." );
  printf("*************************************\n          EM MANUTENCAO          \n*************************************\n");
  sleep(10);
  semaforoOp(idsemS, &UP_write,"UP a atualizar..." );
  printf("Manutencao feita com sucesso");
  break;
  
  case 4 :
  printf("A Mostrar memoria...\n");
  sleep(1);
  mostra_memoria(ouv,mus,play);
  break;
  
  case 0 :
  printf("A Sair...\n");
  exit(0); //mas continua com tudo ligado, seja memorias e tudo
  break;
  
  default :
  printf("Erro\n"); //Erro
  printf("Opcao nao encontrada.\n");
  exit(3);
  }
  
  }
}





/*obs

ver memorias ipcs
destruir a memoria ipcrm -a

*/