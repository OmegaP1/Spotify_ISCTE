#include "includes.h"

int n_aluno;
MsgOuvinte2Server envio;
MsgServer2Ouvinte rececao;
char lista_mus[10];
Tmusica mus[20];
int msg_id_reciver;
int msg_id_sender;
int valor_operacao;
int mypid;
int status;
int a ;
int logout;
char Nickname[100];
char Password[100];


void receber_login(){
rececao.tipo=1;
status = msgrcv(msg_id_reciver, &rececao, sizeof(rececao.dados), mypid , 0);
exit_on_error (status, "Recep��o");
valor_operacao=rececao.dados.status;
status = msgrcv(msg_id_reciver, &rececao, sizeof(rececao.dados), mypid, 0);
exit_on_error (status, "Recep��o");
n_aluno = rececao.dados.myid;

}


void enviar_mensagens(char Nickname[100], char Password[100]){
strcpy( envio.dados.operacao, "");
strcat( envio.dados.operacao, Nickname);
strcat( envio.dados.operacao, Password);
status = msgsnd( msg_id_sender, &envio, sizeof(envio.dados.operacao), 0);
exit_on_error (status, "Envio");
envio.dados.myid=mypid;
status = msgsnd( msg_id_sender, &envio, sizeof(envio.dados), 0);
exit_on_error (status, "Envio");
}


void nick_pass(){
msg_id_reciver = msgget ( 66066, 0600);
exit_on_error (msg_id_sender, "Liga��o");
msg_id_sender = msgget ( 55055, 0600 );
exit_on_error (msg_id_sender, "Liga��o");
printf("Faca o seu login em baixo:\n");
sleep(0.5);
printf("Nickname: ");
scanf( " %s", &Nickname);
printf("Password: ");
scanf( " %s", &Password);
enviar_mensagens(Nickname,Password);
receber_login();
}


void listar_musicas(){
  int c=0;
  strcpy(envio.dados.operacao,"list_musics"); //envia list_musics
  status = msgsnd( msg_id_sender, &envio, sizeof(envio.dados.operacao), 0);
  status = msgsnd( msg_id_sender, &envio, sizeof(envio.dados.info1), 0);
  exit_on_error (status, "Envio");
  
  status = msgrcv( msg_id_reciver, &rececao, sizeof(rececao.dados), n_aluno, 0);
    exit_on_error (status, "Recep��o");
    c = rececao.dados.status;
  if(c != 0){
  int m;  
  for (m=0; (m < c+1) ; m++ ) { 
    status = msgrcv( msg_id_reciver, &rececao, sizeof(rececao.dados.musica), n_aluno, 0);
    mus[m]=rececao.dados.musica;
    exit_on_error (status, "Recep��o");
    printf ("Musica %s %s\n", rececao.dados.musica.ID_MUS, rececao.dados.musica.nome);
  }
}else{
  printf("Playlist nao encontrada.\n");
}
}

void ouvir_playlists(){
int c=0;
  strcpy(envio.dados.operacao,"list_musics"); //envia list_musics
  status = msgsnd( msg_id_sender, &envio, sizeof(envio.dados.operacao), 0);
  status = msgsnd( msg_id_sender, &envio, sizeof(envio.dados.info1), 0);
  exit_on_error (status, "Envio");
  
  status = msgrcv( msg_id_reciver, &rececao, sizeof(rececao.dados), n_aluno, 0);
    exit_on_error (status, "Recep��o");
    c = rececao.dados.status;
  if(c != 0){
  int m;  
  for (m=0; (m < c+1) ; m++ ) { 
    rececao.tipo=1;
    int status1;
    status1 = msgrcv( msg_id_reciver, &rececao, sizeof(rececao.dados.musica), n_aluno, 0);
    mus[m]=rececao.dados.musica;
    exit_on_error (status1, "Recep��o");
     printf ("Musica %s %s %s %d %d %s %d\n", rececao.dados.musica.ID_MUS, rececao.dados.musica.nome, rececao.dados.musica.artista, rececao.dados.musica.duracao, rececao.dados.musica.ano_producao, rececao.dados.musica.genero, rececao.dados.musica.n_vezes);
  }
}else{
  printf("Playlist nao encontrada.\n");
}

}



void associar_playlists(){
int c;
  strcpy(envio.dados.operacao,"get_playlist"); //envia list_musics
  status = msgsnd( msg_id_sender, &envio, sizeof(envio.dados.operacao), 0); // enviar get playlists
  exit_on_error (status, "Envio");
  strcat(envio.dados.info1,":");
  strcat(envio.dados.info1,Nickname);
   status = msgsnd( msg_id_sender, &envio, sizeof(envio.dados.info1), 0); // envia a playlists
  exit_on_error (status, "Envio");
    status = msgrcv( msg_id_reciver, &rececao, sizeof(rececao.dados.info1), n_aluno, 0);
    exit_on_error (status, "Recep��o");
}

void sair(){
 strcpy(envio.dados.operacao,"logout"); //envia logout
  status = msgsnd( msg_id_sender, &envio, sizeof(envio.dados.operacao), 0);
  exit_on_error (status, "Envio");
 
}

void criacao(){
envio.tipo=1;
rececao.tipo = 1;
valor_operacao=0;
a=0;
}

int main(){
criacao();
int id = fork();

if(id==0){
  
  }else{
  envio.dados.myid=getpid();
  mypid=getpid();
    if(a == 0){
      nick_pass();
      printf("\nA processar...\n");
      sleep(1);
        if(valor_operacao== 1){
          printf(" <><><> O Login foi realizado com sucesso <><><>\n");
          a++;  

while(1){
  printf("\n-------- MENU --------\n 1. Listar musicas de playlists\n 2. Ouvir playlists\n 3. Associar a playlist\n 0. Sair (Logout)\n");
  int number;
  scanf( "%d", &number);
  switch(number){

  case 1 :
  printf("Diga a playlist: \n");
  scanf( "%s", &envio.dados.info1);
  printf("A Listar musicas da playlist %s...\n",envio.dados.info1);
  listar_musicas();
  sleep(1);
  break;

  case 2 :
  printf("Diga a playlist: \n");
  scanf( "%s", &envio.dados.info1);
  printf("A Ouvir playlist %s...\n",envio.dados.info1);
  ouvir_playlists();
  sleep(1);
  break;
  
  case 3 :
  printf("Diga a playlist: \n");
  scanf( "%s", &envio.dados.info1);
  printf("A associar playlist...");
  sleep(1);
  associar_playlists();
  break;
  
  case 0 :
  logout=1;
  sair();
  sleep(1);
  status = msgrcv( msg_id_reciver, &rececao, sizeof(rececao.dados), n_aluno, IPC_NOWAIT);
      logout =rececao.dados.status;
  if(logout == 0){
  printf("A Sair...\n");
  exit(0); //mas continua com tudo ligado, seja memorias e tudo
  }else{
  printf("Erro ao sair, tente novamente mais tarde...\n");
  status = msgrcv( msg_id_reciver, &rececao, sizeof(rececao.dados), n_aluno, 0);
    exit_on_error (status, "Recep��o");
    printf("Ja pode tentar sair outra vez!\n");
  }
  break;
  
  default :
  printf("Erro\n"); //Erro
  printf("Opcao nao encontrada.\n");
  exit(3);
  }
  }
  }else{
          printf(" <><><> O Login foi realizado sem sucesso <><><>\n");
          }
  
  }
  }
}