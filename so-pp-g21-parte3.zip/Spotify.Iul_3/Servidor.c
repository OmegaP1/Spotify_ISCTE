#include "includes.h"
#define MAX_OUV 20
#define MAX_PL 20
#define MAX_MUS 20

char nick_pass[100];
MsgServer2Ouvinte enviada;
MsgOuvinte2Server recebida;
Touvinte *ouv;
Tplaylist *play;
Tmusica *mus;
int msg_id_reciver;
int msg_id_sender;
int numero_aluno;
int status;
int idsemS;

void obter_substring(char linha[], char resultado[], char separador, int indice) { //funcao elementar
	int i, j=0, meu_indice = 0;
	for (i=0; linha[i] != '\0'; i++) {
		if ( linha[i] == separador ) {
			meu_indice++;
		} else if (meu_indice == indice) {
			resultado[j++]=linha[i];
		}
	}
	resultado[j]='\0';
}

void cria_memoria_ouv(){
int mem_ouv=shmget(11011, MAX_OUV * sizeof(Touvinte) , 0);
ouv = (Touvinte *)shmat(mem_ouv, 0 , 0);
exit_on_null(ouv, "erro no attach");
printf("\n>>> Conectado a memoria Ouvintes com exito!  <<<");
}

void cria_memoria_play(){
int mem_play=shmget(33033, MAX_PL * sizeof(Tplaylist) , 0);
play = (Tplaylist *)shmat(mem_play, 0 , 0);
exit_on_null(play, "erro no attach");
printf("\n>>> Conectado a memoria Playlists com exito!  <<<\n");
}

void cria_memoria_mus(){
int mem_mus=shmget(22022, MAX_MUS * sizeof(Tmusica) , 0);
mus = (Tmusica *)shmat(mem_mus, 0 , 0);
exit_on_null(mus, "erro no attach");
printf("\n>>> Conectado a memoria Musicas com exito!  <<<");
}

void conect_sem(){
  conectarSemaforo(80808,&idsemS);
  printf("\n>>> Conectado ao semaforo com exito!<<<\n");

}

void cria_memorias(){
cria_memoria_ouv();
cria_memoria_mus();
cria_memoria_play();
conect_sem();
}



void rececao_mensagens(){
recebida.tipo=1;
exit_on_error (msg_id_reciver, "Criacao/Ligacao");
status = msgrcv( msg_id_reciver, &recebida, sizeof(recebida.dados.operacao), 1, 0);
exit_on_error (status, "Recep��o");
 printf ("Mensagem Recebida!\n");
printf ("MENSAGEM <%s>\n", recebida.dados.operacao);
}

void envia_login(int c){
      enviada.dados.status=0;
      if(c !=0){
      enviada.dados.status = 1;
      }
      printf("%d\n",enviada.dados.status);
      status = msgsnd( msg_id_sender, &enviada, sizeof(enviada.dados), 0);
      exit_on_error (status, "Envio");
      printf ("\nMensagem enviada!\n");
      
      enviada.dados.valor1 = numero_aluno;
      status = msgsnd( msg_id_sender, &enviada, sizeof(enviada.dados), 0);
      exit_on_error (status, "Envio");
      printf ("Mensagem enviada!\n");
      enviada.tipo=numero_aluno;

}

void verificacao_login(){
semaforoOp(idsemS, &DOWN_read,"UP a atualizar..." );
status = msgrcv( msg_id_reciver, &recebida, sizeof(recebida.dados), 1, 0);
printf("Novo tipo ID: %d\n",recebida.dados.myid);
printf ("Mensagem Recebida!\n");
enviada.tipo=recebida.dados.myid;
int i,c=0;
for (i=0; (i < MAX_OUV) && ( ouv[i].num != 0 ) ; i++ ) {
   strcpy(nick_pass,"");
   strcat(nick_pass,ouv[i].nick);
   strcat(nick_pass,ouv[i].pass);
   if(strcmp(recebida.dados.operacao,nick_pass) == 0 ){
     numero_aluno = ouv[i].num;
     c++;
   }
}
envia_login(c);
semaforoOp(idsemS, &UP_read,"UP a atualizar..." );
}

void enviar_musica(){
      semaforoOp(idsemS, &DOWN_read,"UP a atualizar..." );
      printf("%s\n",enviada.dados.musica);
      status = msgsnd( msg_id_sender, &enviada, sizeof(enviada.dados.musica), 0);
      exit_on_error (status, "Envio");
      printf ("Mensagem enviada!\n");
      semaforoOp(idsemS, &UP_read,"UP a atualizar..." );
}

void listar_musicas(){
  status = msgrcv( msg_id_reciver, &recebida, sizeof(recebida.dados.info1), 1, 0);
  exit_on_error (status, "Rececao");
  printf ("Mensagem Recebida!\n");
  int i,m,c=0,n=0;
	char linha[250];
 printf("%s\n",recebida.dados.info1);
  for (i=0; (i < MAX_PL)  ; i++ ) { //falta aqui
    if(strcmp(recebida.dados.info1,play[i].nome) ==0){
    c++;
    printf("Playlist encontrada com sucesso\n");
    strcpy(linha,play[i].musicas);
         printf("%s\n",linha);
    
      for(int j=0;j<strlen(linha);j++){
				if(linha[j] == ':'){
					n++;
				}
			}
      enviada.dados.status = n;
      status = msgsnd( msg_id_sender, &enviada, sizeof(enviada.dados), 0);
      exit_on_error (status, "Envio");
      printf ("Mensagem enviada!\n");
      
			for(int k=0; k<n+1; k++){
				obter_substring(linha,enviada.dados.musica.ID_MUS, ':',k);
        printf("id:%s\n",enviada.dados.musica.ID_MUS);
        
        
        for(int m=0; m<MAX_MUS; m++){
          if(strcmp(enviada.dados.musica.ID_MUS , mus[m].ID_MUS) == 0){
            strcpy(enviada.dados.musica.artista,mus[k].artista);
            strcpy(enviada.dados.musica.nome,mus[k].nome);
            enviada.dados.musica.duracao = mus[k].duracao;
            enviada.dados.musica.ano_producao = mus[k].ano_producao;
            strcpy(enviada.dados.musica.genero,mus[k].genero);
            enviada.dados.musica.n_vezes = mus[k].n_vezes;
            enviar_musica();
          }
        }
			}
    }
    }
    if(c==0){
    enviada.dados.status = c;
    status = msgsnd( msg_id_sender, &enviada, sizeof(enviada.dados), 0);
    exit_on_error (status, "Envio");
    printf ("Mensagem enviada!\n");
  }
}

void ouvir_playlist(){
status = msgrcv( msg_id_reciver, &recebida, sizeof(recebida.dados.info1), 1, 0);
  exit_on_error (status, "Rececao");
  printf ("Mensagem Recebida!\n");
  int i,m,c=0,n=0;
	char linha[250];
 printf("%s\n",recebida.dados.info1);
  for (i=0; (i < MAX_PL)  ; i++ ) { //falta aqui
    if(strcmp(recebida.dados.info1,play[i].nome) ==0){
    c++;
    printf("Playlist encontrada com sucesso\n");
    strcpy(linha,play[i].musicas);
         printf("%s\n",linha);
    
      for(int j=0;j<strlen(linha);j++){
				if(linha[j] == ':'){
					n++;
				}
			}
      enviada.dados.status = n;
      status = msgsnd( msg_id_sender, &enviada, sizeof(enviada.dados), 0);
      exit_on_error (status, "Envio");
      printf ("Mensagem enviada!\n");
      
			for(int k=0; k<n+1; k++){
				obter_substring(linha,enviada.dados.musica.ID_MUS, ':',k);
        printf("id:%s\n",enviada.dados.musica.ID_MUS);
        
        
        for(int m=0; m<MAX_MUS; m++){
          if(strcmp(enviada.dados.musica.ID_MUS , mus[m].ID_MUS) == 0){
            strcpy(enviada.dados.musica.artista,mus[k].artista);
            strcpy(enviada.dados.musica.nome,mus[k].nome);
            enviada.dados.musica.duracao = mus[k].duracao;
            enviada.dados.musica.ano_producao = mus[k].ano_producao;
            strcpy(enviada.dados.musica.genero,mus[k].genero);
            mus[k].n_vezes++;
            enviada.dados.musica.n_vezes = mus[k].n_vezes;
            enviar_musica();
          }
        }
			}
    }
    }
    if(c==0){
    enviada.dados.status = c;
    status = msgsnd( msg_id_sender, &enviada, sizeof(enviada.dados), 0);
    exit_on_error (status, "Envio");
    printf ("Mensagem enviada!\n");
  }
}

void associar_playlist(){
  status = msgrcv( msg_id_reciver, &recebida, sizeof(recebida.dados.info1), 1, 0); // recebe a play
  exit_on_error (status, "Rececao");
  printf ("Mensagem Recebida!\n");
  int i,x,c=0,n=0,playlist, nick;
	char linha[250];
 char nickname[40];
 char playnome[40];
   char apoio[20];
   semaforoOp(idsemS, &DOWN_read,"UP a atualizar..." );
   obter_substring(recebida.dados.info1,playnome, ':',0); //retirar o primeiro id para apoio
    obter_substring(recebida.dados.info1,nickname, ':',1); // retirar o nick 
 
  for (i=0; (i < MAX_PL)  ; i++ ) { 
    if(strcmp(playnome,play[i].nome) == 0){ //verificar se a play exite
    playlist=i;
    c++;
    printf("Playlist encontrada com sucesso\n");
    }
  }
   for (x=0; (x < MAX_OUV)  ; x++ ) { 
     if(strcmp(ouv[x].nick,nickname) == 0){ // saber qual e a posicao do nick
     nick = x; 
         strcpy(linha,ouv[nick].playlists); // linha � os ids das playlists
     }
   }    
   for(int j=0;j<strlen(linha);j++){ // quantos ids ha
			if(linha[j] == ':'){
			n++;
				}
			}   
          for(int k=0; k<n+1; k++){ // verificar os ids
          
				  obter_substring(linha,apoio, ':',k); //retirar o primeiro id para apoio
                                         
          printf("id:%s\n",play[playlist].ID_PL);
          printf("id:%s\n",apoio);
          
            if( strcmp(apoio,play[playlist].ID_PL)==0){ 
            strcpy(enviada.dados.info1,"Essa playlist ja foi registada.");
            status = msgsnd( msg_id_sender, &enviada, sizeof(enviada.dados.info1), 0);
            exit_on_error (status, "Envio");
            printf ("Mensagem enviada!\n");
            
            }else{ // quer dizer que nao tem
            strcpy(enviada.dados.info1,"A playlist foi registada com exito!");
            status = msgsnd( msg_id_sender, &enviada, sizeof(enviada.dados.info1), 0);
            exit_on_error (status, "Envio");
            strcat(ouv[nick].playlists, ":");
            strcat(ouv[nick].playlists, play[playlist].ID_PL);
            printf("%s atualizado com exito!", ouv[k].nick);
            printf ("Mensagem enviada, registada!\n");
            }
        }
        semaforoOp(idsemS, &UP_read,"UP a atualizar..." );

}

void verificacao_logout(){
    semaforoOp(idsemS, &DOWN_write,"UP a atualizar..." );
    enviada.dados.status = 0;
    status = msgsnd( msg_id_sender, &enviada, sizeof(enviada.dados), 0);
    exit_on_error (status, "Envio");
    printf ("Mensagem enviada!\n");
    semaforoOp(idsemS, &UP_write,"UP a atualizar..." );

}

int main(){

  msg_id_sender = msgget ( 66066, 0600);
  exit_on_error (msg_id_sender, "Liga��o");
  printf("\n>>> Conectado a fila de mensagens com exito!  <<<");
  msg_id_reciver = msgget ( 55055, 0600);
  exit_on_error (msg_id_sender, "Liga��o");
    printf("\n>>> Conectado a fila de mensagens com exito!  <<<\n");
cria_memorias();

  while(1){
  rececao_mensagens();
  printf("\n%s\n\n",recebida.dados.operacao);
  if(strcmp(recebida.dados.operacao,"list_musics") == 0){
  printf("A Listar musicas da playlist...\n");
  listar_musicas();
  
  }else if(strcmp(recebida.dados.operacao, "listen_playlist") == 0){
   printf("A Ouvir musicas da playlist...\n");
  ouvir_playlist();
  
  }else if(strcmp(recebida.dados.operacao, "get_playlist") == 0){
  associar_playlist();
  printf("A associar playlist");

  }else if(strcmp(recebida.dados.operacao, "logout") == 0){
  verificacao_logout();
  printf("A Sair...\n");
 
  }else{
  printf("A processar a verificacao do login...\n");
  verificacao_login();
  
  }
  strcpy(recebida.dados.operacao,"");
  }

}