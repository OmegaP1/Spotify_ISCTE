#include "/home/so/trabalho-parte-2/spotifiul-media-player/spotifiul-media-player.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <ctype.h>


typedef struct Music{
char Identificacao[10];
char NomeMusica[60];
char NomeInterprete[50];
int Duracao;
char Letra[5000];
} Music;

Music PLAYLIST[20];
char musicasPlaylist[100], playlist[30], playlistName[50];
char * Plline[30];
int isPressionouTecla = 0, isTerminou = 0, isPaused = 0, iterador=0,iterador2=0,NumeroMusica = 0;
int paiPID, pidTimer, pidDisplayGraph, pidDisplayLyrics, pidWait, Numbercount=0;
Music a;

void pressionouNextPrevious(int sinalID) {
	isPressionouTecla = 1;
}

void pressionouQuit(int sinalID) {
    kill(pidDisplayGraph,SIGUSR2);
    kill(pidDisplayLyrics,SIGUSR2);
}

void ProximaMus(){
printf("Proximo grafico");
NumeroMusica++;
}
void Proximaletra(){
printf("Proxima letra");
}

void atualizaGrafico(int sinalID){
 printf("Grafico Atualizado! \n");
}

void escreverLetra(int sinalID){
	printf("Escrevendo letra... \n");
}

void startNStop(int sinalID){
	if( isPaused == 0 )
	isPaused = 1;
	else
	isPaused = 0;
}

//falta funcao para ir buscar os tempo da musica e a letra

void ObterNomePlaylist() {
  printf("Playlist: ");
  scanf("%s", &playlistName);
}

char* ObterPlaylist() {
  FILE *f = fopen("/home/so/trabalho-parte-2/playlists.txt", "r");
  static char linha[80];
  while(fgets(linha, sizeof(linha), f)) {
    if(strstr(linha, playlistName) != NULL) {
      return linha;
    }
  }
  fclose(f);
  printf("Playlist nao encontrada\n");
  exit(1);
}

void app(char pl[20]) {
  strtok(pl, "\n");
  char *token = strtok(pl, ":");
  int i = 0;
  while(token != NULL) {
    Plline[i] = token;
    token = strtok(NULL, ":");
    i++;
    iterador++;   
  }
}

void CriarPlaylist() {
  Music a;
  FILE *fp = fopen("lyrics.db", "rb");
  app(playlist);
  while( fread(&a, sizeof(struct Music), 1, fp) ) {
    for(int i=0; i<iterador; i++) {
      if( i>1 && strcmp(a.Identificacao, Plline[i]) == 0 ) {
        PLAYLIST[iterador2] = a;
        iterador2++;
      }
    }
  }
}

void IniciarMusica(Music g){
  a=g ;
}




int main(){
ObterNomePlaylist();
strcpy(playlist ,ObterPlaylist());
CriarPlaylist();
while(NumeroMusica < iterador2){
IniciarMusica(PLAYLIST[NumeroMusica]);
printf("Musica: %s \n", a.NomeMusica);
printf("Artista : %s \n", a.NomeInterprete);
              pidDisplayLyrics = fork(); // criar novo processo
							if(pidDisplayLyrics == 0 ){
							if(isTerminou == 1){
							return 0;}
							signal(SIGUSR1, escreverLetra);
							signal(SIGUSR2, Proximaletra);
               while(1){
                pause();
              }
           }else{
            pidDisplayGraph = fork();
				  if(pidDisplayGraph == 0 ){
					  if(isTerminou == 1){
					  return 0;}    
					  signal(SIGUSR1, atualizaGrafico);
					  signal(SIGUSR2, ProximaMus);
              while(1){
              pause();
              }
	        }else{
               pidTimer = fork();
	            if (pidTimer == 0) {
  	            if(isTerminou == 1){
      	        return 0;
                 }
	    	        signal(SIGUSR1, startNStop);
                signal(SIGUSR2, pressionouQuit);
   	            for (int i = 0; i < a.Duracao; ++i) { 
                            if( isPaused == 1){
                            pause();
                            }
                printf("Progresso: %d segundos \n", i);
                kill(pidDisplayGraph,SIGUSR1);
                kill(pidDisplayLyrics,SIGUSR1);
                sleep(1);
                }
                NumeroMusica++;
                kill(pidDisplayGraph,SIGUSR2);
                kill(pidDisplayLyrics,SIGUSR2);
                printf("Proxima musica");
              }else{
                pidWait= fork();
	                if (pidWait == 0) {
                  while(1){
                  pause();
                  char c = getch();
                    if (c == 'q') {
                      kill(pidTimer,SIGUSR2);
                      
                    printf("Fechou o programa"); 
           	        exit(1);
                    } else if ( c == 'n' ) { // botao next
                    printf("Proxima musica");
							      kill(pidTimer, SIGUSR2);
						        } else if ( c == ' ') { // play and pause
                              if( isPaused == 0 ){
                              printf("Musica Parada");
                              }else{
                              printf("Musica Iniciada");
                              }
							      kill(pidTimer, SIGUSR1);
						        }
                }
              }else{
              wait(NULL);
              wait(NULL);
              wait(NULL);
              wait(NULL);
            }
          }   
 }
 }
 }
 }