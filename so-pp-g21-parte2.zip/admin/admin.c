#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>

typedef struct Musica{
char id[10];
char nome[60];
char cantor[50];
int Duracao;
char letra[5000];
}db ;

struct Musica musi[500];
struct Musica a;
struct Musica vetor[500];
int is=0;
int contador = 0;

void obter_substring(char linha[], char resultado[], char separador, int indice) {
   int i, j=0, meu_indice = 0;
   for (i=0; linha[i] != '\0'; i++) {
     if ( linha[i] == separador ) { 
       meu_indice++;
     } else if (meu_indice == indice) {
       resultado[j++]=linha[i];
     }
   }
   resultado[j]='\0';
}



char* concatenate(const char* s1, const char* s2) { /*working */
  char* r = malloc(strlen(s1) + strlen(s2) + 1);
  strcpy(r, s1);
  strcat(r, s2);
  return r;
  }

void vvv(char diretoria2[]){
  
  FILE *f = fopen(diretoria2, "r");

        while(!feof(f)){
        fgets(a.nome,1000,f);   
            a.nome[strlen(a.nome)-1] = '\0';
            
        fgets(a.cantor,1000,f);  
            a.cantor[strlen(a.cantor)-1] = '\0';
           
            char line[70]; 
            int nabo=0;
            memset(a.letra, 0, sizeof(a.letra));
            while( fgets(line, sizeof(line), f) ) { 
              strcpy(a.letra, concatenate(a.letra, line));
            nabo++;
            }  
            } 
        
  fclose(f);
}
  
void importarletras(char diretoria[]){    
    DIR *folder = opendir(diretoria);
    struct dirent *entry;

    if(folder == NULL){
        printf("Nao consegue ler o diretorio");
        exit(1);
    }
    
    while((entry=readdir(folder))){
    
      char diretoria2[] = "/home/so/trabalho-parte-2/lyrics/";
      strcat(diretoria2, entry->d_name);
      
      if(strstr(diretoria2, ".lyric")){
      contador++;
      
      vvv(diretoria2);
         
        FILE *musicas = fopen("/home/so/trabalho-parte-2/musicas.txt", "r");
        FILE *lyrics = fopen("lyrics.db", "a");
        char c[1000];
        while(fgets(c,sizeof(c),musicas)){
          if(strstr(c,a.nome) && strstr(c,a.cantor)){
            char duracao[100];
            char id[10];
            obter_substring(c,id,':',0);                                   
            obter_substring(c,duracao,':',3);    
            a.Duracao = atoi(duracao);                                     
            strcpy(a.id, id);
            char line[70]; 
            int nabo=0;
            musi[is] = a;
            printf("%s\n", musi[is].id);
            is++;
            
            }
    }
    fclose(lyrics);
    fclose(musicas);
    }

}   
closedir(folder);
}



void importfinal(char diretoria[]){
importarletras(diretoria);
FILE *lyrics = fopen("lyrics.db", "rb+");
for(int i=0;i<500;i++){ 
  /*rewind(lyrics);  
  int load=0;                   
  int j = 0;
  int stop = 0;
  while(fread(b,sizeof(struct Musica), 1, lyrics) && stop == 0){ 
    if(strcmp(b.id, musi[i].id)==0 && stop == 0){
      load = 1;
      fseek(lyrics, j*sizeof(struct Musica), SEEK_SET);
      fwrite(&b, sizeof(struct Musica), 1, lyrics);
      stop = 1;
    }
    j++;
  } 
  if(load==0){*/
    fwrite(&musi[i], sizeof(struct Musica),1,lyrics);
    //vetor[i] = musi[i];                
}
fclose(lyrics);
}


void mostrarLetras() {
  struct Musica a;
  FILE * f = fopen("lyrics.db","rb");
  while(fread(&a,sizeof(struct Musica),1,f)){
    printf("%s \n \n \n", a.letra);
  }
}



void main(){
int n;
char d[10];
printf("Escolha uma das Opcoes:\n 1. Importar Letras\n 2. Mostrar Letras\n");
scanf( "%c", &n);
switch(n){

case '1' :
printf("A Importar Letras...\n");
importfinal("/home/so/trabalho-parte-2/lyrics/");
exit(1);



case '2' :
printf("A Mostrar Letras...\n");
mostrarLetras();
exit(1);

}

}