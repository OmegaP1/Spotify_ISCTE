#!/bin/bash
if [ -f $HOME/public_html/stats.html ]; then #verifica se exite um diretorio com um ficheiro "stats.html"
echo ""
else
cd #muda de diretorio
mkdir public_html #cria o diretorio
touch stats.html #cria o ficheiro html
cd Spotify.Iul #muda para o diretorio a ser usado
fi 

  echo "<html>
  <head>
  <meta charset="UTF-8">
  <title>Ouvintes e playlists da aplica��o Spotify-IUL</title>
  </head>
  <body>" > ~/public_html/stats.html
    cat ouvintes.txt | while read linha; do #le os ouvintes
    nickname=$( cat ouvintes.txt | grep "$linha" | cut -d ':' -f1 )
    numeroPlaylistOuvinte=$( cat ouvintes.txt | grep "$linha" | grep -o "PL_" | wc -l )
    contador1=$(( $numeroPlaylistOuvinte+1  ))
    echo " <h1>Nickname: $nickname</h1>" >> ~/public_html/stats.html
      for(( c=1; c<$contador1; c++ )); do #cria o ciclo 
      numeroPlaylist=$( cat ouvintes.txt | grep "$linha" | cut -d ':' -f7- | cut -d ':' -f$c ) #como o c=1 comeca na primeira playlist que o ouvinte tem
      nomePlaylists=$( cat playlists.txt | grep "$numeroPlaylist" | cut -d ':' -f2 ) #obtem o nome da playlist
      echo " <h2>Playlist: $nomePlaylists</h2>
      <ol>" >> ~/public_html/stats.html
      numeroMusicasPlaylist=$( cat playlists.txt | grep "$nomePlaylists" | grep -o "MUS_" | wc -l ) #obtendo o nome da playlist conta se o numero de "MUS" na playlist
      contador=$(( $numeroMusicasPlaylist+3 )) #cria um contador com +3 pois � necessario que o contador do for inicialize a 3 de modo a nao ser preciso criar outra variavel
        for(( int=3; int<$contador; int++ )); do #cria um ciclo e obtem todas as partes da msuica para adicionar ao html
        musicasPlaylist=$( cat playlists.txt | grep "$nomePlaylists" | cut -d ':' -f$int ) #obtem os diversos nomes das playlists
        buscarnomemuscia=$( cat musicas.txt | grep "$musicasPlaylist" | cut -d ':' -f2 | head -1 ) 
        buscarArtistaMusica=$( cat musicas.txt | grep "$musicasPlaylist" | cut -d ':' -f3 | head -1 )
        buscarDuracaoMusica=$( cat musicas.txt | grep "$musicasPlaylist" | cut -d ':' -f4 | head -1 )
        buscarAnoMusica=$( cat musicas.txt | grep "$musicasPlaylist" | cut -d ':' -f5 | head -1 )
        buscarGeneroMusica=$( cat musicas.txt | grep "$musicasPlaylist" | cut -d ':' -f6 | head -1 )
        buscarTopMusica=$( cat musicas.txt | grep "$musicasPlaylist" | cut -d ':' -f7 | head -1 )
        echo "<li><b>$buscarnomemuscia</b> -<i> Artist: </i>$buscarArtistaMusica;<i> Duration: </i>$buscarDuracaoMusica; <i> Year: </i>$buscarAnoMusica;<i> Genre: </i>$buscarGeneroMusica;<i> Top Position: </i>$buscarTopMusica</li>" >> ~/public_html/stats.html
        done
      done
    done
  echo "</body> </html>" >> ~/public_html/stats.html
