#!/bin/bash
echo nome da musica:
read musicaa
echo nome do artista:
read artista
echo duracao da musica
read duracao
echo ano de producao:
read prod
echo genero:
read genero
if [ -f musicas.txt ]; then #ve se o ficheiro existe, se nao cria
echo "Ficheiro criado"
else
touch musicas.txt
fi
a=$( cat constm.txt | wc -l )
b=$( cat musicas.txt | grep "$musicaa:$artista" | wc -l ) #procura pelo nome da msuica e pelo artista
  if [ $a -eq 0 ]; then  #verifica o contador externo se ja foi criado
  cat musicas.txt | wc -l >> constm.txt
  fi
  musica=$( cat constm.txt | cut -d ' ' -f1 )
  contador=$(( $musica + 1 ))
  if [ $b -eq 1 ]; then #Ve se esse arsita com aquela musica ja existem
  echo Musica ja adicionada
  exit
  else
  echo MUS_$contador:$musicaa:$artista:$duracao:$prod:$genero: >> musicas.txt #adiciona a musica
  echo Musica adicionada com sucesso
  sed -i "s/"$musica"/"$contador"/" constm.txt
  fi
