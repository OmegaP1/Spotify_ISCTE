#!/bin/bash
echo " Pertende atualizar as horas?
1. sim
2. nao"
read resposta
minutoshoras=$( cat cron.txt | cut -d ' ' -f1-2) # vai buscar os minutos e as horas do cron.txt
case $resposta in
1) 
echo " Para que horas pertende mudar?"
read horas
if [ $horas -gt 24 ]; then #delimita as horas a 24
echo "horas invalidas"
./diario_atualiza_html.sh
exit
fi
echo " Para que minutos pertende muda?"
read minutos
if [ $minutos -gt 60 ]; then #delimita os minutos a 60
echo "minutos invalidas"
./diario_atualiza_html.sh
exit
fi
variavel="$minutos $horas"
sed -i "s/$minutoshoras/$variavel/" cron.txt #troca no ficheiro cron.txt 
crontab cron.txt #atualiza o cron com as novas horas e minutos
echo "Atualizado com sucesso!"
;;
2)
echo "Nada feito"
;;
*)
echo "Resposta invalida!"
;;
esac
