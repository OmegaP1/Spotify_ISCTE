#!/bin/bash
if [ -f playlists.txt ]; then #verifica se o ficheiro playlists.txt ja esta no sistema
echo "Ficheiro criado"
else
touch playlists.txt # se nao, cria
fi
echo "Indique o nome da playlists"
read pp
playlist=$(cat playlists.txt | wc -l)
inicio="PL_$(( playlist + 1 )):$pp" #cria a variavel com o indicador da playlists + o nome da playlist
if [ $( cat playlists.txt | grep "$pp" | wc -l ) -ge 1 ]; then #verifica se a playlist ja esta no sistema
  echo "Playlist ja criada!"
  exit
else
  echo "$(cat musicas.txt)" #mosta as musicas disponiveis no sistema
  echo "Que musicas quer adicionar?"
  read escrito
    for numeros in $escrito #le o ficheiro "escrito"
    do
      if [ $( cat musicas.txt | grep "MUS_$i" | wc -l ) -ne 0 ]; then
        inicio="$inicio:MUS_$numeros"
      else
        echo "esta musica nao existe"
      fi  
    done
  echo $inicio >> playlists.txt #adiciona a playlist
  echo "Playlist criada com sucesso"
  cat playlists.txt | sort -n #arranja a playlist
fi