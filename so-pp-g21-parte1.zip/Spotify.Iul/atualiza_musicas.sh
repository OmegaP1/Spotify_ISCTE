#!/bin/bash
echo indique o nome do ficheiro que pertende adicionar:
read ficheiro
  cat $ficheiro | while read linefile; do # le linha a linha o ficheiro dado
  nomemusicaartista=$( cat $ficheiro | grep "$linefile" | cut -d ':' -f1-2 ) # da o nome da musica e do artista do ficheiro dado
  linhamusica=$( cat $ficheiro | grep "$linefile" | cut -d ':' -f1- ) #da a linha toda do ficheiro dado
  verificarseexiste=$( grep -i "$nomemusicaartista" musicas.txt | wc -l ) 
      if [ $verificarseexiste -eq 0 ]; then #verifica se o nome do artista e a musca ja estao no sistema
      musica=$(cat constm.txt | cut -d ':' -f1) #se nao, acrescenta as musicas
      contador=$(( $musica + 1 ))
      echo "MUS_$contador:$linhamusica" >> musicas.txt
      echo "Musica adicionada com sucesso!"
      sed -i "s/"$musica"/"$contador"/" constm.txt
      else
      sabernumerolinha=$( grep -n "$nomemusicaartista" musicas.txt | cut -d ':' -f1 )
      linhamusicaficheiro=$( cat musicas.txt | grep -i "$nomemusicaartista" | cut -d ':' -f2-  )  #da a linha toda do ficheiro musicas, sem a inical "MUS_"
      sed -i "s/$linhamusicaficheiro/$linhamusica/g" "musicas.txt"  #se sim, atualiza as restantes informacoes 
      echo "Musica atualizada com sucesso!"
      fi
  done
   