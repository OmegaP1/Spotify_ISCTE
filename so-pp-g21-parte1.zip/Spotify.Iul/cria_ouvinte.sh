#!/bin/bash
if [ -f ouvintes.txt ]; then #Verifica se o ficheiro ouvintes.txt existe no sistema
echo "Ficheiro criado"
else
touch ouvintes.txt #se nao, cria
fi
echo "introduza o seu nickname:"
read nickname
echo "introduza a sua password:"
read pass
echo "introduza o seu numero de aluno:"
read numero
echo "introduza o seu cruso:"
read curso 
a=$( cat ouvintes.txt | grep $nickname | wc -l )
b=$( cat /etc/passwd | grep $numero | wc -l )
  if [ $a -ge 1 ]; then #verifica se o nickname ja esta no sistema a ser utilizado
  echo Este utilizador ja existe
  exit
  else if [ $b -ne 1 ]; then # verifica atras do numero de aluno se o user pode se increver no sistema
  echo Este utilizador nao esta no Sistema
  exit
  else if [[ $curso != "ETI" && $curso != "IGE" && $curso != "LEI"  ]]; then #verifica se o curso � valido
  echo Curso invalido
  exit
  else
  nome=$( grep $numero /etc/passwd | cut -d ':' -f5)
  apelido=${nome::-3}
  echo $nickname:$pass:$numero:$apelido:a$numero@iscte.iul.pt:$curso >> ouvintes.txt #acrescenta ao sistema o ouvinte
  echo Utiliziador criado com sucesso
  fi
  fi
  fi
  