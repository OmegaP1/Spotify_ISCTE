#!/bin/bash
if [ -f constm.txt ]; then #verifica se o ficheiro das constantes existe
echo "o ficheiro existe"
else
echo "0" > constm.txt #se nao, cria
fi
while true; do #criar ciclo para continuar a usar o menu
echo "-------- MENU --------
1. Cria ouvinte
2. Adiciona musica
3. Atualiza musicas
4. Cria playlist
5. Associa ouvinte a playlist
6. Remove musica de playlist
7. Mostra estatisticas
8. Publica playlists
9. Atualizacao diaria HTML (configuracao)
0. Sair"
read numero
case $numero in #para abrir os ficheiros
  1) ./cria_ouvinte.sh ;;
  2) ./adiciona_musica.sh ;;
  3) ./atualiza_musicas.sh ;;
  4) ./cria_playlists.sh ;;
  5) ./associa_ouvinte_playlist.sh ;;
  6) ./remove_musica_playlist.sh ;;
  7) ./stats.sh ;;
  8) ./publica_playlists.sh ;;
  9) ./diario_atualiza_html.sh ;;
  0) exit ;;
  *)
  echo "numero escolhido nao listado"
  exit ;;
esac
done

