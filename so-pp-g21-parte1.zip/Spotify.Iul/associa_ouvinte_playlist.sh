#!/bin/bash
echo "Indique o user"
read user
ajuda=$( cat ouvintes.txt | grep -i "$user:") 
  if [ $( cat ouvintes.txt | grep -i $user | wc -l) -lt 1 ]; then #vai verificar se o nickname existe no sistema
    echo "Nickname invalido"
    exit
  else
  echo "$(cat playlists.txt)" #mostra as plyalists do sistema
  echo "Indique o nome da playlist a Adicionar"
  read playlist
  a=$( cat playlists.txt | grep -i $playlist | cut -d ':' -f2 | wc -l) 
    if [ $a -eq 0 ]; then #verifica se a playlist esta no sistema
      echo "Playlist invalida"
      exit
    fi 
  ajudaa=$ajuda:$( cat playlists.txt | grep -i $playlist | cut -d':' -f1)
  sed -i "/$ajuda/d" ouvintes.txt 
  echo "$ajudaa" >> ouvintes.txt #adiciona a playlist ao ouvinte
  echo "Playlist adicionada com sucesso!"
fi