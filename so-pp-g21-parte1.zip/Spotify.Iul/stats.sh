#!/bin/bash
while true; do #cria um ciclo para nao sair do ficheiro
echo "-------- MENU --------
1. Numero de ouvintes, musicas e playlists
2. Numero total de minutos de musicas
3. Numero de musicas numa playlists
4. Ouvintes por curso 
0. Sair"
read numero
a=$( cat ouvintes.txt | wc -l)
b=$( cat musicas.txt | wc -l)
c=$( cat playlists.txt | wc -l)
total=0
j=$( cat musicas.txt | cut -d ':' -f4 | wc -w ) #conta o numero de intrevalos (palavras) apos -f4
  for (( contador=1; contador < $j; contador++ )); do #inicia o ciclo
  d=$( cat musicas.txt | cut -d ':' -f4 | head -$contador | tail -1 ) #vai cortando apartir do -fa 1 por 1
  total=$(( $total+$d )) #vai adicionando os minutos
  done
g=$( cat ouvintes.txt | grep -c "LEI" )
h=$( cat ouvintes.txt | grep -c "ETI" )
i=$( cat ouvintes.txt | grep -c "IGE" )
case $numero in
  1) echo "Numero de ouvintes: $a     Numero de musicas: $b     Numero de playlists: $c"  ;;
  2) echo "Numero total de minutos de musicas: $total " ;;
  3) echo "Diga a playlist que perdente:"
  read play
  j=$( cat playlists.txt | grep -i $play | wc -l ) 
  if [ $j -eq 0 ]; then #verificia se exite a playlist
  echo "Playlist inexistente"
  exit
  fi
  e=$( cat playlists.txt | grep "$play" | cut -d ':' -f3- ) #ve as musicas da playlist
  f=$( cat playlists.txt | grep "$play" | grep -o "MUS_" | wc -l )  #Conta o numero de musicas que tem a playlist
  echo " A playlist $play tem $f musicas, sendo elas as seguintes: $e " ;;
  4) echo " Numero de ouvintes de LEI : $g     Numero de ouvintes de ETI : $h     Numero de ouvintes de IGE : $i"  ;;
  0) exit ;;
  *)
  echo "numero escolhido nao listado"; exit ;;
  esac
  done