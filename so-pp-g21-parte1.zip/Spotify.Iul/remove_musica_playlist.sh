#!/bin/bash
echo $(cat playlists.txt | cut -d ':' -f2)
echo Escolha o nome de uma playlists:
read playlist
playlistid=$( cat playlists.txt | grep -i $playlist | cut -d ':' -f1-2 )
playlistnumb=$( cat playlists.txt | grep -i $playlist | cut -d ':' -f1 )
allplay=$( cat playlists.txt | grep -i $playlist )
a=$( cat playlists.txt | grep -i $playlist | wc -l )
  if [ $a -eq 0 ]; then #verifica se existe a playlist no sistema
  echo "Playlist invalida!"
  exit
  else
  echo $( cat playlists.txt | grep -i $playlist | cut -d ':' -f3- )
  echo escolha uma musica:
  read musica
  b=$( cat playlists.txt | grep -i $playlist | grep -i $musica | wc -l )
    if [ $b -eq 0 ]; then #verifica se existe a musica no sistema
    echo "Musica invalida!"
    exit
    else
    sed -i "/$allplay/ s/:MUS_$musica//" playlists.txt
    c=$( cat playlists.txt | grep -i $playlistnumb | grep "MUS_" | wc -c )
    echo "MUS_$musica removida com exito!"
      if [ $c -eq 0 ]; then #Verifica se a playlist ficou vazia (sem musicas)
      sed -i "/$playlistid/d" playlists.txt | grep -i $allplay
      echo "$playlistnumb" foi eleiminada
        cat ouvintes.txt | while read ouvi; do
        d=$( cat ouvintes.txt | grep "$ouvi" | grep "$playlistnumb" | wc -l )
          if [ $d -eq 1 ]; then #Verifica se algum ouvinte tem aquela playlist 
            if [ -f emails.txt ]; then #verifica se exite um emails.txt
            echo "Ficheiro criado"
            else
            touch emails.txt
            fi
          e=$( cat ouvintes.txt | grep "$ouvi" | cut -d ':' -f3 )
          cat ouvintes.txt | grep "$e" | sed -i "/$e/ s/:$playlistnumb//" ouvintes.txt #retira a "MUS_" a ser removida
          echo �Envia e-mail para "$e"@iscte-iul.pt. Conteudo: Foi apagada a playlist "$playlistnumb" que estava associada ao seu utilizador� >> emails.txt
          fi
        done
      fi
    fi
  fi   